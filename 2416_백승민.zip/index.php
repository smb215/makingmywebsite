<!doctype html>
<html lang="ko">
<meta charset="UTF-8">
<?php
include('./board/db.php');
session_start();
if(!isset($_SESSION['id']) || !isset($_SESSION['password'])) {
  echo "<a href='board/login.php'>로그인</a>이 되어있지 않습니다.";
}
else{
$id = $_SESSSION['id'];
$password = $_SESSSION['password'];
echo "<p><a href='board/logout.php'>로그아웃</a></p>";
}
?>
 <head>
  <title>게시판</title>
  <link rel="stylesheet" href="style.css" />
 </head>
 <body>
 <h1>자유게시판</h1>
 <h4>자유롭게 글을 쓸 수 있는 게시판입니다.</h4>
 <div id="board_area"> 
<table class="list-table">
	<thead>
    	<tr>
        	  <th width="70">번호</th>
            <th width="500">제목</th>
            <th width="120">글쓴이</th>

      </tr>
  </thead>

  <?php
    $sql = "SELECT * FROM dbtable2 ORDER BY `num` ASC  ";
    $result = mysql_query($sql,$conn);
  ?>

    <?
    while($row = mysql_fetch_array($result)){
    ?>
  <tbody>
        <tr>
            <td width="70"><? echo $row['num'];?></td>
            <td width="500"><a href="./board/read.php?idx=<? echo $row['num'];?>"><? echo $row['title'];?></a></td>
            <td width="120"><? echo $row['id'];?></td>
        </tr>
  </tbody>
  <? } ?>
</table>
<div class="btn">
  <br></br><br></br>
  <a href="board/write.php"><button> 글쓰기 </button></a>
  <a href="board/login.php"><button> 로그인 </button></a>
  <a href="board/register.php"><button> 회원가입</button></a>
  <input type="button" value="제작자 정보" onclick="alert('wp 2416 백승민')">
</div>
 </body>
 </div>
</html>