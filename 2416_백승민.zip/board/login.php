<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<title>로그인</title>
</head>
<body>
	<form action="./member_login.php" method="post">
		아이디 : <input type="text" name="id"><br>
		비밀번호 : <input type="password" name="password"><br>
		<input type="submit" value="로그인">
	</form>
	<a href="http://smb215.dothome.co.kr/board/register.php"><button> 회원가입 </button></a>
</body>
</html>