<meta charset="utf-8">
<?
	include('./db.php');
	session_start();
	if(!isset($_SESSION['id']) || !isset($_SESSION['password'])) {
 	echo "<script>alert('로그인이 필요한 서비스입니다. 로그인 후 이용해주세요'); history.back();</script>";
 	exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>글쓰기</title>
</head>
<body>
	<form action="./member_write.php" method="post">
		제목 입력 : <input type="text" size="48" name="title"><br><br>
		내용 입력 : <textarea cols="100" rows="40" name="contents"></textarea><br><br>
		<input type="submit" value="글쓰기">
	</form>
</body>
</html>