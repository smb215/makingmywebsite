<meta charset="utf-8">
<?
	include('./db.php');
	session_start();
	$title = $_POST['title'];
	$contents = $_POST['contents'];
	$id = $_SESSION['id'];
	$result = mysql_query("SELECT id FROM dbtable WHERE id = '$id'");
	$row = mysql_fetch_row($result);
	$sql="INSERT INTO dbtable2 (`id`,`title`,`contents`) VALUES ('$row[0]','$title','$contents')";
	$result = mysql_query($sql,$conn); 
	echo "<script> location.href='http://smb215.dothome.co.kr'; </script>";
?>