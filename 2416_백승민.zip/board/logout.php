<?
session_start();
session_destroy();
?>
<meta http-equiv='refresh' content=0;url='http://smb215.dothome.co.kr/'>