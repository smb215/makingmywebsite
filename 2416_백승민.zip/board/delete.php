<?
	session_start();
	$bno=$_SESSION['bno'];
	$id=$_SESSION['id'];
	$sql = "SELECT * FROM dbtable2 WHERE num ='$bno'";
	$result = mysql_query($sql,$conn);
	$row = mysql_fetch_array($result);

	if($id==$row['id']){
		$sql = "DELETE * FROM dbtable2 WHERE id='$id'"; 
	}
	else{
		echo "오류발생";
	}
?>