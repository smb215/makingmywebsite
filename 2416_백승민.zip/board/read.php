<meta charset="UTF-8">
<?

	include('./db.php');
	$bno = $_GET['idx'];
	session_start();
	$_SESSION['bno']=$bno;
	$sql = "SELECT title FROM dbtable2 WHERE num='".$bno."'";
	$result = mysql_query($sql,$conn);
	$row = mysql_fetch_array($result);


	echo "제목 : ";
	echo nl2br($row[0]);
	echo "<p>";

	$sql = "SELECT contents FROM dbtable2 WHERE num='".$bno."'";
	$result = mysql_query($sql,$conn);
	$row = mysql_fetch_array($result);
	echo nl2br($row[0]);
	echo "<p>";
?>