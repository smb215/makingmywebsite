<!doctype html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <title>게시판</title>
  <link rel="stylesheet" href="style.css" />
 </head>
 <body>
 <h1>자유게시판</h1>
 <h4>자유롭게 글을 쓸 수 있는 게시판입니다.</h4>

 <div id="board_area"> 
<table class="list-table">
	<thead>
    	<tr>
        	  <th width="70">번호</th>
            <th width="500">제목</th>
            <th width="120">글쓴이</th>
            <th width="100">작성일</th>
            <th width="100">조회수</th>
      </tr>
    </thead>
</table>
<div class="btn">
  <br></br><br></br>
	<a href="board/write.php"><button> 글쓰기 </button></a>
  <a href="board/login.php"><button> 로그인 </button></a>
  <a href="board/register.php"><button> 회원가입</button></a><br><br>
</div>
<div class="btn2">  
  <input type="button" value="제작자 정보" onclick="alert('wp 2416 백승민')">
  <input type="reset">
</div>
 </body>
 </div>
</html>
