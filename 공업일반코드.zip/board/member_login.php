<meta charset="utf-8">
<?
	include('./db.php');

	$id=$_POST['id'];
	$password=$_POST['password'];

	$sql="SELECT id FROM dbtable WHERE `id`='$id'";
	$result=mysql_query($sql,$conn);
	$ID=mysql_fetch_array($result);
	
	if($ID=['id']){
		$sql="SELECT password FROM dbtable WHERE `password`='$password'";
		$result=mysql_query($sql,$conn);
		$PASSWORD=mysql_fetch_array($result);
		if($PASSWORD=['password']){
			echo "<script> alert('로그인 성공.'); location.href='http://smb215.dothome.co.kr';</script>";
		}
		else{
			echo "<script> alert('비밀번호가 일치하지 않습니다.'); history.back(); </script>";
			exit();
		}
	}else{
		echo "<script> alert('아이디가 존재하지 않습니다.'); history.back();</script>";
		exit();
	}
?> 