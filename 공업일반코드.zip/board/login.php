<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<title>로그인</title>
</head>
<body>
	<form action="./member_login.php">
		아이디 : <input type="text"><br>
		비밀번호 : <input type="password"><br>
		<input type="submit" value="로그인">
	</form>
</body>
</html>