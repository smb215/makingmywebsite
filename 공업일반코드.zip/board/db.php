<?
   $conn=mysql_connect("localhost","smb215","smbaek2183");
   mysql_select_db('smb215', $conn);
   mysql_query('set names utf8');

?>