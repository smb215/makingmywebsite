<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<title>글쓰기</title>
</head>
<body>
	<form action="http://smb215.dothome.co.kr/board/write.php">
		제목 입력 : <input type="text" size="48"><br><br>
		내용 입력 : <textarea cols="50" rows="20"></textarea><br><br>
		<input type="submit" value="글쓰기">
</body>
</html>