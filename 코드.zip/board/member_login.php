<meta charset="utf-8">
<?
	include('./db.php');

	$id=$_POST['id'];
	$password=$_POST['password'];

	$sql="SELECT * FROM dbtable WHERE id='{$_POST[id]}' AND password='{$_POST[password]}'";

	$result=mysql_query($sql,$conn);
	$LOGIN=mysql_fetch_array($result);

	if(!empty($LOGIN)){
		echo "<script> alert('로그인 성공.'); location.href='http://smb215.dothome.co.kr';</script>";
	}
	else{
		echo "<script> alert('로그인 실패.'); history.back();</script>";
		exit();
	}
?> 