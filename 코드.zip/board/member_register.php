<meta charset="utf-8">
<?
	include('./db.php');

	$name=$_POST['name'];
	$id=$_POST['id'];
	$password=$_POST['password'];

	$sql="SELECT id FROM dbtable WHERE `id`='$id'";
	$result=mysql_query($sql,$conn);
	
	if(mysql_num_rows($result) > 0)
	{
		echo "<script>alert('아이디가 이미 사용중입니다.'); history.back();</script>";
		exit();
	}

	$sql="SELECT password FROM dbtable WHERE `password`='$password'";
	$result=mysql_query($sql,$conn);

	echo mysql_error();

	if(mysql_num_rows($result) > 0)
	{
		echo "<script>alert('비밀번호가 이미 사용중입니다.'); history.back();</script>";
		exit();
	}

	$sql = "INSERT INTO dbtable (`name`, `id`, `password`) values ('$name', '$id' , '$password')";
	$result = mysql_query($sql, $conn);

	echo "<script> alert('회원가입이 완료되었습니다.'); location.href='http://smb215.dothome.co.kr';</script>";
?> 